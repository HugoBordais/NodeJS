``` bash
npm install
```

A partir d'ici, personnellement j'utilise 2 fénétres de terminal.

Run le server socket.

``` bash
npm run server
```

Run server dev.

``` bash
npm run client
```
