module.exports = [
  {
    name: 'Starcraft 2',
    image: 'chatrooms/sc2.jpg'
  },
  {
    name: 'League of Legend',
    image: 'chatrooms/leagueoflegend.jpg'
  }
]
