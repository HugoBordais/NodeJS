module.exports = [
  {
    name: 'Jim',
    lastName: 'Raynor',
    statusText: 'Give us the best shot',
    image: 'users/jim_raynor.jpg'
  },
  {
    name: 'Artanis',
    statusText: 'We are the blades of Aiur',
    image: 'users/artanis.jpg'
  },
  {
    name: 'Sarah',
    lastName: 'Kerrigan',
    statusText: 'Live for the swarm',
    image: 'users/sarah_kerrigan.jpg'
  },
  {
    name: 'Zeratul',
    lastName: '',
    statusText: 'The Key will guide you to the Xel\'Naga',
    image: 'users/zeratul.jpg'
  },
  {
    name: 'Thresh',
    lastName: '',
    statusText: 'The chain warden',
    image: 'users/thresh.jpg'
  },
  {
    name: 'Ornn',
    lastName: '',
    statusText: 'God of the volcanic forge',
    image: 'users/ornn.jpg'
  },
  {
    name: 'Alistar',
    lastName: '',
    statusText: 'Minotaur',
    image: 'users/alistar.jpg'
  },
]

